package edu.umb.cs680.hw03;

enum StudentStatus{
    INSTATE, OUTSTATE, INTL
};