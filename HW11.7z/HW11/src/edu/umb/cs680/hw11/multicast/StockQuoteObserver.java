package edu.umb.cs680.hw11.multicast;

public interface StockQuoteObserver {

	public void updateStock(StockEvent arg);
	
}