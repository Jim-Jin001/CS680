package edu.umb.cs680.hw11.multicast;

public interface DJIAQuoteObserver {

	public void updateDJIA(DJIAEvent arg);
	
}
